import React from "react";

function Visual(props) {
  return <figure id="visual" className={props.type}></figure>;
}

export default Visual;
