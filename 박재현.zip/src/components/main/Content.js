import React from "react";

function Content() {
  return <section>Content</section>;
}

export default Content;
